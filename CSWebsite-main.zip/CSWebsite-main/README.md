README for website
Tasks:
4/16/25
Submission database
resources
slidedeck
